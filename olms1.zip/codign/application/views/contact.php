<!DOCTYPE html>
<html>
<head>
</head>
<style>
	.bi{
	background-image:url("../img/3.jpg");
	background-size:cover;
	color: red;

}

	input,textarea
	{
		padding:10px;
		margin:10px;
		text-align: center;
		
	}
	fieldset
	{

		width:300px;
		height:170px;
		margin-top: 210px;
		background-color: ff000ff;
		color:white;
	;
		

	}
	form h2
	{
		margin-left: 300px;

	}
	table
	{
		
		text-align: center;

	}
	.cl
	{
		font-size: 18px;
	}
</style>
<body class="bi">
	<center>
		<h2>CONTACT</h2>
	
<form class="cl">
	<fieldset>
		<legend>contact us</legend>

		<table>
			<tr>
				<td>
			<h3>phonenumber:</h3></td>
			<td><input type="text" name="contact" value="9995986905" readonly>
				</td>
			</tr>
			<br>
			<tr>
				<td>
			<h3>email:</h3></td>
			<td><input type="text" name="contact" value="orisys@gmail.com" readonly>
				</td>
			</tr>
			
		</table>
	</fieldset>
</form>
</center>
</body>
</html>

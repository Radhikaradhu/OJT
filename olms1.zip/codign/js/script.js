// function myFunction()
// {
// 	//$("h1").fadeToggle(3000);
// 	//$("#sec").fadeToggle(2000);	
// $(".secc").fadeToggle(3000);

// }
//alert('hai');
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>

	</style>
</head>
<body>
	<form method="post" action="<?php echo base_url()?>main/fo">
	<fieldset>
	Email:<input type="email" name="email"></form></body><br>
	password:<input type="password" name="password"><br>
	
	<input type="submit" name="update" value="login">
	</fieldset>
</form>
</body>
</html>
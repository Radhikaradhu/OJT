<?php
$link=mysqli_connect("localhost","root","","db_table");
if($link===false)
{
    die ("not connected sucessfully");
}

?>
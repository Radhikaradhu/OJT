<!DOCTYPE html>
<html>
<head>
<title>
</title>
<style>
input{
	padding:20px;
	margin:10px;
}

</style>
</head>
<body>
<form action="login.php" method="GET">
<fieldset style="width:300px;height:600px;margin-left:400px">
<legend style="color: red"><strong>Employee login</strong></legend>

empname<br>
<input type="text" name="name"><br>

emppassword<br>
<input type="password" name="pass"><br>
<input type="submit" name="sub" value="Login">
</fieldset>
</form>
</body>
</html>
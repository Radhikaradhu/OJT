<!DOCTYPE html>
<html>
<head>
<title>
</title>
<style>
input{
	padding:20px;
	margin:10px;
}

</style>
</head>
<body>
<form action="insert.php" method="GET">
<fieldset style="width:300px;height:600px;margin-left:400px">
<legend style="color: red"><strong>Employee details</strong></legend>
empid<br>
<input type="text" name="id"><br>
empname<br>
<input type="text" name="name"><br>
empno<br>
<input type="text" name="num"><br>
empaddress<br>
<textarea name="address"></textarea><br>
empemail<br>
<input type="email" name="email"><br>
emppassword<br>
<input type="password" name="pass"><br>
<input type="submit" name="sub" value="submit">
</fieldset>
</form>
</body>
</html>